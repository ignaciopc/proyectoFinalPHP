<?php

define("base_url","http://localhost/proyectos/php/proyectoFinalPHP/");
define('controller_default', 'productoController');
//Definición de método por defecto
define('action_default', 'index');



?>