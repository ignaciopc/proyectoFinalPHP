</div>
</div>

			<!-- PIE DE PÁGINA -->
			<footer id="footer">
				<p>Desarrollado por Ignacio Palomar   &copy; <?= date('Y') ?></p>
			</footer>
		</div>
	</body>
</html>